#!/usr/bin/env python3

import sanic

server = sanic.Sanic("GrocList")
server.static("/favicon.ico", "/Users/thomas/git/cs101/grocerylist/favicon.ico")


@server.route("/")
async def index(request):
    url = request.url
    args = request.args

    msg = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Title of the document</title>
            <link rel="icon" type="image/png" href="/favicon.ico">
        </head>
        <body>
            <p>Hello, World!</p>
            <p>I see you arrived at the URL: {url}.</p>
            <p>And with these arguments: {args}</p>
        </body>
        </html>
        """

    return sanic.response.html(msg)


@server.route("/groclist")
async def groclist(request):
    items = load()

    args = request.args
    if "add" in args:
        values = args["add"]
        for value in values:
            if value not in items:
                items.append(value)

    if "del" in args:
        values = args["del"]
        for value in values:
            if value in items:
                items.remove(value)

    save(items)
    msg = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Title of the document</title>
            <link rel="icon" type="image/png" href="/favicon.ico">
        </head>
        <body>
            <ul>
        """
    for item in items:
        msg += f"<li>{item}</li>"
    msg += """
            </ul>
        </body>
        </html>
        """
    return sanic.response.html(msg)


def save(items):
    plain_text = "\n".join(items)
    the_file = open("/Users/thomas/git/cs101/grocerylist/items.list", "w")
    the_file.write(plain_text)
    the_file.close()


def load():
    the_file = open("/Users/thomas/git/cs101/grocerylist/items.list", "r")
    plain_text = the_file.read()
    items = plain_text.split("\n")
    return items


if __name__ == "__main__":
    server.run(host="0.0.0.0", port=8003)
